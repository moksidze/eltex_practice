#!/bin/bash

PIPE="/tmp/run/cuckoo.pid"
LOG="cuckoo.log"

mkdir -p /tmp/run

if [ ! -p "$PIPE" ]; then
    mkfifo "$PIPE"
fi

echo "$(date '+%F %T') Startup!" >> "$LOG"

cleanup() {
    echo "$(date '+%F %T') Shutdown!" >> "$LOG"
    rm -f "$PIPE"
    exit 0
}

trap cleanup SIGINT

while true
do
    if read line < "$PIPE"
    then
        if [[ "$line" =~ ^(.+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]
        then
            NAME="${BASH_REMATCH[1]}"
            PID="${BASH_REMATCH[2]}"
            N=$((RANDOM%9+2))

            echo "$(date '+%F %T') $NAME[$PID] $N" >> "$LOG"

            echo "$N" > "/tmp/run/$PID.reply"
        fi
    fi
done
