#!/bin/bash

CONF="observer.conf"
LOG="observer.log"

while read SCRIPT
do
    if [ -z "$SCRIPT" ]; then
        continue
    fi

    if ! ls /proc/*/cmdline 2>/dev/null | xargs grep -l "$SCRIPT" >/dev/null 2>&1
    then
        nohup "./$SCRIPT" >/dev/null 2>&1 &
        echo "$(date '+%F %T') restarted $SCRIPT" >> "$LOG"
    fi

done < "$CONF"
