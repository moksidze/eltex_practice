#!/bin/bash

SCRIPT=$(basename "$0")

if [ "$SCRIPT" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

PID=$$
LOG="report_${SCRIPT}.log"

echo "$(date '+%F %T') [$PID] Скрипт запущен" >> "$LOG"

mkfifo "/tmp/run/$PID.reply"

echo "$SCRIPT[$PID]: how much time do I have?" > /tmp/run/cuckoo.pid

read N < "/tmp/run/$PID.reply"

rm "/tmp/run/$PID.reply"

sleep "$N"

echo "$(date '+%F %T') [$PID] Скрипт завершился, работал $N секунд." >> "$LOG"
